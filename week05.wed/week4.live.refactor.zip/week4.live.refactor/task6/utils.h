#pragma once

// in a .h file, 2 things:
//  function prototypes
//  variable declarations* and type definitions

int findMaxOf3Ints(int, int, int);