// these are routines for cleaning/ensuring good input

// props to Tom for suggesting!

#pragma once
#include <stdbool.h>

bool RemoveBadChars(char* input);

